# ud036_StarterCode
Source code for a Movie Trailer website.



Background: The Movie Trailer Website project stores a list of movie titles, 
an image of the movie poster, information on the movie, and a movie trailer. 
Visitors can review the movies and watch the trailers:



Instructions
1. Download the file folder
2. Run the entertainment_center file
3. Notice the html page gets created in the folder
4. Navigate to the webbrowser and view the html page


Download the code from the git account https://github.com/wilsoncorie/Full_Stack_Projects
Download the folder movie mni project
There are no outside requirements. Please verify that you have internet access


Systems/Programs
Python 2.7 was used to create these files and run the file.
The html file created can be viewed in Firefox or Internet Explorer 
